import gensim.models as g
import gensim.models.word2vec as v
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
import nltk
import re

#input corpus
#train_corpus = "metin/duz_metinler.txt"
train_corpus = "metin/orwell.txt"

#output model
saved_path = "metin/model.bin"

#train doc2vec model
kitap = g.doc2vec.TaggedLineDocument(train_corpus)
model = g.Doc2Vec(kitap, vector_size=100, window=10, min_count=1, sample=1e-3, workers=1, hs=1, dm=0, negative=5, dbow_words=1, dm_concat=1, epochs=200)


model.save(saved_path)

def tsne_plot(model):
  labels = []
  tokens = []

  for word in model.wv.vocab:
    tokens.append(model[word])
    labels.append(word)

  tsne_model = TSNE(perplexity=40, n_components=2, init='random', n_iter=5000)
  new_values = tsne_model.fit_transform(tokens)
   
  x = []
  y = []
  for value in new_values:
    x.append(value[0])
    y.append(value[1])

  plt.figure(figsize=(20, 20))
  for i in range(400):
    plt.scatter(x[i],y[i])
    plt.annotate(labels[i],
                 xy=(x[i], y[i]),
               xytext=(5, 2),
               textcoords='offset points',
                  va='bottom')
  plt.show()
            
tsne_plot(model)
